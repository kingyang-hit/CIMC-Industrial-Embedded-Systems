/************************************************************
 * ��Ȩ��2025CIMC Copyright�� 
 * �ļ���Headerfiles.h
 * ����: Lingyu Meng
 * ƽ̨: 2025 CIMC IHD V04
 * �汾: Lingyu Meng     2023/2/16     V0.01    original
************************************************************/

#ifndef __HEADERFILES_H
#define __HEADERFILES_H

/************************* ͷ�ļ� *************************/

#include "gd32f4xx.h"
#include "gd32f4xx_libopt.h"
#include "systick.h"
#include <stdio.h>
#include <stdint.h>
#include "string.h"
#include "Function.h"     // ִ�к���
#include "LED.h"
#include "RTC.h"
#include "SPI_FLASH.h"
#include "adc.h"
#include "USART1.h"
#include "oled.h"
#include "KEY.h"
#include "DAC.h"
#include "spi_port.h"
#include "gd30ad3344.h"
#include "PMU.h"
#include "zhenjiexi.h"
#include "rom.h"            // �ṩ internal_flash_* ����
#include "BootConfig.h"     // �ṩ BOOT_CONFIG_ADDR �� BootParam_t ��
#endif

/****************************End*****************************/

