/************************************************************
 * ��Ȩ��2025CIMC Copyright��
 * �ļ���PMU.h
 * ����: Jialei Zhao
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Jialei Zhao     2026/06/01     V0.01    original
************************************************************/

#ifndef __PMU_H
#define __PMU_H

#include "HeaderFiles.h"

void lowpower_sleep(void);
void lowpower_deepsleep(void);
void lowpower_standby(void);
static void rcu_config(void);
void lowpower_init(void);
#endif

