/************************************************************
 * ��Ȩ��2025CIMC Copyright��
 * �ļ���usart.c
 * ����: Jialei Zhao
 * ƽ̨: 2025CIMC IHD-V04
 * �汾: Jialei Zhao     2026/2/4     V0.01    original
************************************************************/


/************************* ͷ�ļ� *************************/

#include "rom.h"

/************************* �궨�� *************************/


/************************ �������� ************************/


/************************ �������� ************************/

/************************************************************
 * Function :       internal_flash_erase
 * Comment  :       �����ڲ�flashҳ(4KB)����
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
//!�ڲ�flashҳ(4KB)����
void internal_flash_erase(uint32_t addr)
{

	fmc_unlock();  //fmc����
	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	//ҳ����
	fmc_page_erase(addr);

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}
/************************************************************
 * Function :       internal_flash_earse_sector
 * Comment  :       �����ڲ�flash��������
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
void internal_flash_earse_sector(uint32_t addr)
{
	fmc_unlock();  //fmc����
	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	//�Ȳ���
	fmc_sector_erase(addr);

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}
/************************************************************
 * Function :       internal_flash_write
 * Comment  :       �����ڲ�flash����д��
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
//!����д��
void internal_flash_write(uint32_t addr , uint16_t data)
{
	fmc_unlock();

	fmc_halfword_program(addr , data);

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}
/************************************************************
 * Function :       internal_flash_write_word
 * Comment  :       �����ڲ�flash��д��
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
//!����д��
void internal_flash_write_word(uint32_t addr , uint32_t data)
{
	fmc_unlock();

	fmc_word_program(addr , data);

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}

/************************************************************
 * Function :       internal_flash_write_str
 * Comment  :       �����ڲ�flash�ַ���д��
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
void internal_flash_write_str(uint32_t addr , uint16_t* data , uint16_t len)
{
	fmc_unlock();

	for (uint16_t i = 0; i < len; i++)
	{
		fmc_halfword_program(addr + i * 2 , data[i]);
	}

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}
/************************************************************
 * Function :       internal_flash_write_str_Char
 * Comment  :       �����ڲ�flash�ַ���д��(�ַ���)
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
void internal_flash_write_str_Char(uint32_t addr , uint8_t* data , uint32_t len)
{
	fmc_unlock();

	for (uint32_t i = 0; i < len; i++)
	{
		fmc_byte_program(addr + i , data[i]);
		while(fmc_flag_get(FMC_FLAG_BUSY));
		// printf("Progress is %d%%\r\n" , (i * 100 / len));
	}

	fmc_flag_clear(FMC_FLAG_END); //���FMCæµ��־λ
	fmc_flag_clear(FMC_FLAG_WPERR);
	fmc_flag_clear(FMC_FLAG_PGSERR);
	fmc_flag_clear(FMC_FLAG_PGMERR);

	fmc_lock();
}
/************************************************************
 * Function :       internal_flash_read
 * Comment  :       �����ڲ�flash���ֶ�ȡ
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
uint16_t internal_flash_read(uint32_t addr)
{
	return *(volatile uint16_t*)(addr);
}
/************************************************************
 * Function :       internal_flash_read_Char
 * Comment  :       �����ڲ�flash�ַ��Ͷ�ȡ
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
uint8_t internal_flash_read_Char(uint32_t addr)
{
	return *(volatile uint8_t*)(addr);
}

/************************************************************
 * Function :       internal_flash_read_word
 * Comment  :       �����ڲ�flash�ֶ�ȡ
 * Parameter:       null
 * Return   :       null
 * Author   :       Jialei Zhao
 * Date     :       2026-2-4 V0.1 original
************************************************************/
uint32_t internal_flash_read_word(uint32_t addr)
{
	return *(volatile uint32_t*)(addr);
}

/****************************End*****************************/
