.\objects\zhenjiexi.o: ..\Protocol\zhenjiexi\zhenjiexi.c
.\objects\zhenjiexi.o: ..\Protocol\zhenjiexi\zhenjiexi.h
.\objects\zhenjiexi.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\zhenjiexi.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
